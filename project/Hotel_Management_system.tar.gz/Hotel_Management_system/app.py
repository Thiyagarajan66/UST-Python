import json

import pymongo
from flask import Flask, flash, render_template, request
import random

client = pymongo.MongoClient("mongodb://localhost:27017")
print(client)
db = client["Hotel_Management"]
collection = db["Employee"]
# credentials = {"username":"admin", "password":"admin123"}
# collection.insert_one(credentials)
# first = collection.find()
# print(first)

app = Flask(__name__)

app.config["SECRET_KEY"] = "sdfa%^A&s$66aDD"

@app.route('/')
def index():
    return render_template('index.html')


@app.route('/logout', methods=['GET'])
def logout():
    if request.method == 'GET':
        return render_template('index.html')

@app.route('/get_employee_form', methods=['GET'])
def get_employee_form():
        return render_template('employee.html')

@app.route('/add_employee', methods=['GET'])
def add_employee():
        return render_template('add_employee.html')


@app.route('/home', methods=['GET'])
def home():
        return render_template('home.html')


@app.route('/guest', methods=['GET'])
def guest():
        return render_template('guest.html')


@app.route('/create_employee', methods=['POST'])
def create_employee():
    if request.method == 'POST':
        print("create employee api hit successfully...")
        username = request.form.get('username')
        password = request.form.get('password')
        email = request.form.get('email')
        dob = request.form.get('dob')
        role = request.form.get('role')
        yoe = request.form.get('yoe')
        result = collection.find_one({"username": username})
        if result:
            raise Exception("Username already exists. Try another")
        emp_json = {
            "username": username,
            "password": password,
            "email": email,
            "role": role,
            "yoe": yoe,
            "dob": dob
        }
        collection.insert_one(emp_json)
        return render_template('emp_success.html')

@app.route('/login', methods=['POST'])
def login():
    if request.method == 'POST':
        print("Login Api hit successfully...")
        username = request.form.get('username')
        password = request.form.get('password')
        result = collection.find_one({"username": username})
        if result:
            if password == result["password"]:
               # return "Logging successfully"
               task = result["task"] if result.get("task") else "No task allocated"
               return render_template('home.html', task=task)
            else:
                flash("Pasword incorrect")
                return render_template('index.html')
        else:
            return render_template('index.html')



if __name__ == "__main__":
    app.run(host = '0.0.0.0', debug=True, port=8000)   